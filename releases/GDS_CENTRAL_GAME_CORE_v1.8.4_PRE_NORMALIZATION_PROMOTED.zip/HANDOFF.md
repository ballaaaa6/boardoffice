# GDS Central Game Core — Handoff

**Updated:** 2026-08-31 (Asia/Bangkok)
**Project root:** `D:\antigravity\board office`
**Status:** `PHASE8C_IMPLEMENTED_ACCEPTANCE_PENDING`
**Active handoff:** this file only

## Source of truth

- The unpacked project at the root is the active source of truth.
- `00_STARTING_POINT/` is the immutable four-file archive received at project start.
- `ROADMAP.md` defines milestone order; `AGENTS.md` defines working rules.
- `docs/history/` contains state snapshots only. They are not active handoffs.
- A manifest/report status does not replace explicit author acceptance.
- The original four-file project baseline remains preserved in `00_STARTING_POINT/`. The TV Studio Story archive currently stored there is external research evidence, not project status or a release input.

## Where the project is now

- Phase 8B navigation/world foundation is author-approved and remains frozen.
- Phase 8C portal actor lifecycle is implemented and wired through `RUNTIME/central_core.py`.
- The lifecycle runs `unspawned → entering → active → exiting → despawned`, keeps deterministic actor identity/movement data, and ends invisible after portal exit.
- Crowd movement/portal QA support is present.
- Phase 8C has not yet passed the author's visual acceptance and clean-release gate; do not start Phase 8D yet.

## Latest verification

- Full regression from the new root: `146 passed`.
- Focused portal/movement/crowd regression: `24 passed`.
- Focused Portal/Crowd/WorkSeat comparison regression after the TV Studio Story review: `39 passed`.
- Room Navigation: PASS.
- Navigation Occupancy: PASS for 25 floors / 219 workstations.
- WorkSeat: PASS.
- Phase 6 Spatial: PASS.
- F2 gameplay-metadata family: PASS.
- Central integrity: PASS, with `release_clean=false` because the working tree contains ignored caches/review outputs.
- Existing local Phase 8C visual/closeout artifacts are stale evidence: the representative crowd report uses renderer schema v3 and still records the removed nested-root paths, while `REPORTS/PHASE8C_CLOSEOUT.json` records the older 121-test run. Regenerate closure evidence from the current root before acceptance.
- The existing `releases/GDS_CENTRAL_GAME_CORE_v1.8.4.zip` is an old candidate, not the promotable closeout archive: it still contains `HANDOFF_v1.8.3.md` and predates the current root documentation contract. Preserve it until a new candidate passes fresh-extraction verification.
- Fresh dense visual QA is now generated at `LOCAL_REVIEW/PHASE8C_DENSE_10_ACTOR_QA_20260831/`: F0, F1, F2 plus deterministic random floors F14 and F17 (seed `8042`), 10 actors per floor, farthest-point room coverage. The report is PASS with zero active waits, zero collisions, zero static-world diff pixels and all actors despawned.
- Focused portal/crowd regression: `27 passed`; current full regression: `146 passed`. All seven required root audits pass; root Central reports `pass=true` and `release_clean=false` only because local Python caches exist.
- Clean release candidate fresh-extraction verification is complete: `146 passed`, all seven audits exit zero, Central `pass=true`, `release_clean=true`, Python cache count `0`, payload mismatches/missing `0`. Candidate: `releases/GDS_CENTRAL_GAME_CORE_v1.8.4_CLOSEOUT_CANDIDATE.zip` (staged copy verified identically). The archive hash is recorded in this root handoff after the final build so it is not self-referential inside the archive.

## Most recent project changes

- Re-rooted the repository at `D:\antigravity\board office`; the former nested project directory was removed after its contents and `.git` metadata were moved successfully.
- Archived the four received starter files in `00_STARTING_POINT/` without editing them.
- Consolidated project status into this single active `HANDOFF.md`.
- Renamed former handoffs under `docs/history/` as non-authoritative state snapshots.
- Added the English documentation map at `docs/INDEX.md` and the repeatable release gate at `docs/RELEASE_CHECKLIST.md`.
- Independently checked the supplied TV Studio Story map, chip and visit-animation evidence against the extracted source package. The evidence supports separated portal semantics and object-owned interaction metadata, but does not expose runtime scheduling/queue algorithms or fully decode the foreign interaction tuple.
- Added the QA-only `TOOLS/render_phase8c_dense_crowd_qa.py` wrapper. It does not alter runtime behavior; it records the dense five-floor sample, deterministic random seed, room-wide target sampling and actual GIF frame counts.
- No runtime logic, registries, world assets or character assets were changed during this organization work.

## Research input awaiting author decision

- The TV reference does not reset Phase 8C: the current GDS portal lifecycle already separates navigation portal data from world art and has explicit inside/outside plus entry/exit rules. Phase 8C visual acceptance remains the immediate gate.
- A future directional entry/exit lane refinement is optional and should be added only if Phase 8C crowd/portal visual review demonstrates a real bottleneck or crossing defect.
- The strongest Phase 8D lesson is an object-owned interaction-slot contract layered over the existing WorkSeat geometry, transition gate and pose compositor. Start with one deterministic slot per workstation while keeping the schema extensible to multiple slots.
- GDS already has the semantic character action registry in `CHARACTER/ACTIONS/gds_standard_v1.json`; Phase 8D should extend/reuse it rather than create a competing registry.
- No TV tuple values, scheduler behavior or queue policy should be copied as fact without runtime/code evidence.

## Next exact task

1. Freeze the current 8C baseline and generate fresh representative portal/crowd QA for F0, F1 and the F2 family from the root project.
2. Review entry/exit pairing, fade order, facing, speed, walking depth, crowd clearance and final despawn with the author; record an explicit decision per floor.
3. If any sample is rejected, fix only the observed 8C defect, add or update regression coverage, and repeat the representative review.
4. After visual approval, run the full regression and every required release audit from the root.
5. Create a clean archive, fresh-extract it, rerun the regression/audits there and require `release_clean=true`.
6. After author visual approval, promote the verified candidate, synchronize the manifest, README, closeout report, checksums, roadmap and this handoff with the accepted evidence; only then mark Phase 8C closed and move to the Phase 8D contract.

## Current blocker

Phase 8C visual acceptance has not yet been recorded. Phase 8D remains gated on that decision and release normalization.
