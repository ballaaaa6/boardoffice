# Extraction Report — TV_Studio_Story_v1.2.7

## Scope

This delivery performs the reproducible static intake, Unity/TextAsset extraction, custom Kairo pack recovery, exact pack round-trip validation, visual cataloging, format inventory, and raw code/metadata preservation described by the supplied Pocket Academy 3 workflow.

It does **not** claim that every game-specific binary format, gameplay state machine, save codec, or runtime branch has been fully reverse-engineered. Those require separate per-game semantic and native-analysis waves.

## Source

- File: `tv-studio-story-v127-mod-modyolo.apk`
- Size: 64,154,521 bytes
- SHA-256: `7dbe3a4611c9145dc353c5dc420d8650ca07f51fb96245ce140026e3953d9f88`
- Source APK included here: No

## Static results

- APK ZIP entries: 1,346
- Parsed Unity serialized containers: 1,202
- TextAssets: 26
- Parsed Kairo packs: 17
- Extracted pack files: 3,310
- Byte-identical pack round-trips: 17/17
- Image files recognized: 1,257
- Focused raw-code strings: 8,682

## Confidence

- `CONFIRMED_STATIC`: APK inventory, Unity versions, raw-code files, pack names, filenames, sizes, offsets, flags, image dimensions.
- `CONFIRMED_ROUNDTRIP`: every pack marked true in `pack_manifest.csv`.
- `RUNTIME_REQUIRED`: live selection behavior, exact animation choice in gameplay, save path/container ordering, and effects of mutations.

## Important differences from the Pocket Academy 3 example

The custom pack container is structurally compatible, but this title may use a different repeating XOR key family. The key family is recorded by label and length; raw key material is retained in the toolchain implementation for reproducibility. Game-specific SEB/OPT/map semantics may differ and are therefore inventoried conservatively rather than overclaimed.
