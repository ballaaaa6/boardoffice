# Limitations and Next Analysis Waves

This archive is a static extraction and engineering handoff, not a recovered Unity project. It intentionally stops before unsupported claims.

Recommended next waves:

1. Build a game-specific semantic SQLite index joining data tables, model IDs, SEB/OPT resources, maps, and code names.
2. Recover and round-trip each game-specific map/model/save/event format.
3. Generate composed animation previews and isometric map renders where the title's SEB/OPT variants are confirmed.
4. Run targeted IL2CPP or Mono analysis for projection, depth, routing, queues, facility lifecycle, AI, economy, events, and save.
5. Perform runtime capture only on a legally controlled test device/emulator, keeping runtime claims separate from static evidence.
