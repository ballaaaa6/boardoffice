# GDS CENTRAL GAME CORE v1.8.0

> v1.8.0 คือรุ่น **Phase 8B Single-Character Movement Foundation** โดยคงหลัก Lean Central Runtime Derivation ของ v1.7.0 และเพิ่ม A* pathfinding + movement runtime สำหรับตัวละคร 1 คนบน navigation ที่ derive จากข้อมูลกลาง

สูตร navigation หลักยังเป็น:

`WALKABLE = APPROVED ROOM DOMAIN - ACTIVE OBJECT FOOTPRINTS`

สิ่งที่เพิ่มใน v1.8.0:

- `WORLD/RUNTIME/pathfinding_core.py` — deterministic A* แบบ 4-neighbor, cost=1, Manhattan heuristic
- `RUNTIME/character_movement_core.py` — แปลง fine-grid cell center เป็น screen pixel และแมปทิศ `+U=SE`, `-U=NW`, `+V=SW`, `-V=NE`
- ใช้ action `move` / `idle` เดิมของระบบตัวละครเท่านั้น ไม่สร้างภาพ movement ใหม่
- shared ground anchor ของตัวละคร = `[16,31]` บน canvas 32×42
- `CentralGameCore` มี facade สำหรับ pathfinding, portal start, distant target และ character movement
- Floor00 ผ่าน proof 3 แบบ: near target / distant target / workstation approach และ smoke test ผ่านบน F0/F1/F2/F36
- reception F2/F2+ เพิ่มพื้นที่จองไปทาง `-U` อีก 5 fine-cells โดยยังใช้ visual-bounds-relative origin เพื่อไม่ให้ transparent padding ของแต่ละ asset ทำให้ footprint เลื่อน

กฎ Lean Release ยังเหมือนเดิม:

- เก็บ Room mask canonical แค่ 3 ชุดใน `WORLD/COMPILED_NAV/`
- **ไม่แพ็ก** `WORLD/COMPILED_NAV/OCCUPANCY/`
- **ไม่แพ็ก** `PREVIEW/`, GIF และ QA contact sheet ที่สร้างใหม่ได้
- งานภาพ review ใช้ asset จริง + deterministic compositor เท่านั้น ห้ามใช้โมเดลสร้างภาพ
- Portal lifecycle/fade/despawn เป็น Phase 8C, WorkSeat runtime takeover เป็น Phase 8D, walking depth/occlusion เป็น Phase 8E และ multi-character ทำภายหลัง

อ่าน `HANDOFF.md` และ `REPORTS/PHASE8B_MOVEMENT_FOUNDATION.json` สำหรับสถานะล่าสุด
