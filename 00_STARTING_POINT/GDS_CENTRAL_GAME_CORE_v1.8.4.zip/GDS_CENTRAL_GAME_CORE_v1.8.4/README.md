# GDS CENTRAL GAME CORE v1.8.2

> v1.8.2 is the hardened canonical Phase 8B release. It preserves the v1.7.0 Lean Central Runtime Derivation policy and carries forward the author-approved F0/F1/F2 navigation geometry from v1.8.1, then hardens walking occlusion, F2→F2+ gameplay metadata synchronization, and F2-family Reception navigation anchoring.

## Phase 8B status

**HARDENED CANONICAL / AUTHOR APPROVED — 2026-08-30**

## Navigation formula

```text
FINAL_OCCUPIED = BASE_OBJECT_FOOTPRINTS + SEMANTIC_CLOSURES + NAVIGATION_CLEARANCE
WALKABLE       = APPROVED_ROOM_DOMAIN - FINAL_OCCUPIED
```

Clearance is navigation-only and does not alter base ground/depth anchors.

## Canonical Room / Portal geometry

| Family | Room cells | Portal inside cells |
|---|---:|---:|
| F0 | 4129 | 12 |
| F1 | 5950 | 21 |
| F2 / F2+ | 7942 | 28 |

F0 and F1 remain unique. All 23 floors using `layout.floor02.large` now resolve gameplay/spatial metadata through the explicit `gameplay.layout.floor02.large` family with `floor02` as canonical.

## Phase 8B hardened runtime

- deterministic 4-neighbor A* pathfinding
- fine-grid movement (`+U=SE`, `-U=NW`, `+V=SW`, `-V=NE`)
- shared character ground anchor `[16,31]`
- semantic desk↔chair and desk↔desk closures
- desk/chair +4 navigation clearance with boundary/pair relief
- exterior WorkSeat transition gates
- **no-redraw walking depth:** completed world is rendered once; foreground world geometry masks actor alpha instead of redrawing furniture over actors
- explicit F2 gameplay metadata family audit/runtime
- F2-family Reception fixed navigation ground anchor independent of transparent visual padding

## F2/F2+ Reception lock

Visual semantic anchor remains:

```text
sprite-left x = 221
visible alpha-top y = 355
```

Navigation reference:

```text
canonical ground anchor = (259,376)
profile origin offset   = -10U, 0V
axes                    = 29U × 15V
occupied cells          = 435
world corners           = (239,366) (297,395) (267,410) (209,381)
```

This is the prior 20×15 reservation expanded **again** by `-U5` and `+U4`. All 23 F2-family floors produce identical Reception navigation geometry.

## Final navigation state

| Floor | Room | Base | Closure | Clearance | Occupied | Walkable | Portal |
|---|---:|---:|---:|---:|---:|---:|---:|
| F0 | 4129 | 710 | 116 | 1091 | 1917 | 2212 | 12 |
| F1 | 5950 | 1176 | 156 | 1347 | 2679 | 3271 | 21 |
| F2 / F2+ | 7942 | 1713 | 220 | 1675 | 3608 | 4334 | 28 |

## Lean release policy

Keep canonical assets/shared blobs, registries, runtime, tests, schemas and small reports. Do not package generated QA images/GIFs, `PREVIEW/`, `WORLD/COMPILED_NAV/OCCUPANCY/`, Python caches, or pytest caches.

## Verification

Source regression after Gate A/B/C: **114/114 tests PASS** (`26+34+34+20`).

Required release audits cover Room Navigation, Ground Footprints, Navigation Occupancy (25 floors / 219 workstations), WorkSeat, Phase 6 Spatial, Central package integrity, and F2 gameplay-metadata/Reception synchronization.

See `HANDOFF.md`, `DOCS/NAVIGATION_OCCUPANCY_CONTRACT.md`, and `REPORTS/PHASE8B_CLOSEOUT.json`.

## Next milestone

**Phase 8C — Portal Spawn / Fade-In / Exit / Despawn lifecycle.**
