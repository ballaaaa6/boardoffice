from __future__ import annotations

import hashlib
from io import BytesIO
from pathlib import Path

from PIL import Image

from .layout_core import LayoutCore


def rgba_sha256(image: Image.Image) -> str:
    image = image.convert("RGBA")
    payload = image.size[0].to_bytes(4, "big") + image.size[1].to_bytes(4, "big") + image.tobytes()
    return hashlib.sha256(payload).hexdigest()


def png_sha256(image: Image.Image) -> str:
    bio = BytesIO()
    image.save(bio, format="PNG")
    return hashlib.sha256(bio.getvalue()).hexdigest()


class FloorRenderer:
    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.core = LayoutCore(self.root)

    def render(self, floor_id: str) -> Image.Image:
        skin = self.core.floor_skin(floor_id)
        canvas = self.core.load_variant(skin["base_variant_id"]).copy()
        for placement in self.core.resolve_floor_placements(floor_id):
            sprite = self.core.load_variant(placement["variant_id"])
            canvas.alpha_composite(sprite, (int(placement["x_px"]), int(placement["y_px"])))
        return canvas

    def render_rgba_sha256(self, floor_id: str) -> str:
        return rgba_sha256(self.render(floor_id))

    def render_png_sha256(self, floor_id: str) -> str:
        return png_sha256(self.render(floor_id))

    def render_to(self, floor_id: str, output: str | Path) -> Path:
        output = Path(output)
        output.parent.mkdir(parents=True, exist_ok=True)
        self.render(floor_id).save(output)
        return output
