# GDS CENTRAL GAME CORE — CURRENT HANDOFF / PHASE 8 ROADMAP

**Handoff date:** 2026-08-30  
**Current canonical baseline:** `GDS_CENTRAL_GAME_CORE_v1.8.2`  
**Primary status:** **PHASE 8B HARDENED CANONICAL / AUTHOR APPROVED**  
**Next milestone:** **Phase 8C — Portal Spawn / Fade-In / Exit / Despawn lifecycle**

---

# 0. NON-NEGOTIABLE PROJECT RULE — IMAGE WORK

All visual work uses **real project assets + deterministic code/PIL/compositor only**. Do not use image generation, AI repainting, or invented visual content.

---

# 1. SOURCE OF TRUTH

```text
v1.7.0  Lean Central Runtime Derivation
v1.8.0  provisional Phase 8B movement candidate
v1.8.1  Phase 8B canonical closeout
v1.8.2  PHASE 8B HARDENED CANONICAL (current)
```

Continue future gameplay implementation from `v1.8.2`.

---

# 2. PHASE 8B CLOSED SCOPE

Phase 8B freezes:

- deterministic 4-neighbor A* pathfinding
- fine-grid character movement using existing move/idle assets
- shared character ground anchor `[16,31]`
- no-redraw walking-depth occlusion
- semantic desk↔chair closure
- desk↔desk seam closure / arbitrary connected desk clusters
- desk/chair navigation clearance
- chair Room-boundary relief
- chair↔chair separate-island pair relief
- exterior WorkSeat transition gates
- author-approved F0/F1/F2 Room Domain + Portal geometry
- explicit F2 canonical gameplay-metadata family inherited by every F2+ skin
- F2-family reception fixed navigation ground anchor and expanded reservation

---

# 3. PERMANENT FINE GRID

```text
profile: grid.iso.occupancy_fine.v1
cell:    4×2 px
U step:  (+2,+1)
V step:  (-2,+1)
origin:  (28,0)

+U = SE
-U = NW
+V = SW
-V = NE
```

---

# 4. FINAL ROOM / PORTAL GEOMETRY

| Family | Room cells | Portal inside cells | Contract |
|---|---:|---:|---|
| F0 | 4129 | 12 | unique; entrance wedge expanded |
| F1 | 5950 | 21 | unique; lower-left domain/portal author-approved |
| F2 / F2+ | 7942 | 28 | F2 canonical; +V2 connector expansion |

F0 and F1 remain unique. All 23 floors using `layout.floor02.large` inherit F2 gameplay/spatial metadata.

---

# 5. ACTIVE NAVIGATION FORMULA

```text
FINAL_OCCUPIED
=
BASE_OBJECT_FOOTPRINTS
+ SEMANTIC_CLOSURES
+ NAVIGATION_CLEARANCE

WALKABLE
=
APPROVED_ROOM_DOMAIN
- FINAL_OCCUPIED
```

Clearance is navigation-only and must not change base ground/depth anchors.

---

# 6. CLEARANCE / RELIEF

```text
desk  +4 on -U/+U/-V/+V
chair +4 on -U/+U/-V/+V
```

Chair boundary rule: clip to Room Domain, then relieve the boundary-facing buffer side by 2 cells.  
Chair pair rule: for separate furniture islands, mutually facing chair buffers may relieve 1 cell each to preserve a 2-cell corridor.  
F1 CEO chair exception: `-U clearance = 0`.

Base footprint and semantic closure cells may never be removed by relief.

---

# 7. WALKING DEPTH — NO-REDRAW CONTRACT

The completed floor is rendered **once**. Dynamic occlusion must never redraw furniture over a walking actor.

```text
completed floor once
→ resolve foreground occluders from ground depth
→ mask actor alpha where world geometry is in front
→ composite actor only
```

This replaces the old `floor → actor → redraw furniture` path that could alpha-composite baked shadows repeatedly. Static world pixels outside actor bounds must remain byte-identical across walking frames and crowd density.

---

# 8. F2 GAMEPLAY METADATA FAMILY

Registry/runtime:

```text
WORLD/REGISTRY/gameplay_metadata_families.json
WORLD/RUNTIME/gameplay_metadata_family_core.py
```

Canonical family:

```text
family_id:          gameplay.layout.floor02.large
layout_id:          layout.floor02.large
canonical_floor_id: floor02
family_floor_count: 23
```

Synchronized from F2:

- fine grid
- room domain
- portal
- layout/workstation geometry
- workstation directions
- footprint policy
- navigation clearance / closure / final occupancy

Per-floor visual skins remain independent: backgrounds, furniture art, reception art and foreground overlays may differ.

---

# 9. F2/F2+ RECEPTION CANONICAL LOCK

Visual reception remains locked by semantic visual anchor:

```text
sprite-left x = 221
visible alpha-top y = 355
```

Navigation is independent of transparent visual padding:

```text
canonical navigation ground anchor world px = (259,376)
profile origin offset from anchor = -10U, 0V
```

The prior `20×15` reservation was expanded **again** by `-U5` and `+U4`, producing:

```text
axes: 29U × 15V
occupied cells: 435
P0 = (239,366)
P1 = (297,395)
P2 = (267,410)
P3 = (209,381)
```

Every one of the 23 F2-family floors must produce these exact world corners and 435 reception cells, regardless of asset alpha-left/top padding.

---

# 10. FINAL NAVIGATION STATE

| Floor | Room | Base | Closure | Clearance | Occupied | Walkable | Portal |
|---|---:|---:|---:|---:|---:|---:|---:|
| F0 | 4129 | 710 | 116 | 1091 | 1917 | 2212 | 12 |
| F1 | 5950 | 1176 | 156 | 1347 | 2679 | 3271 | 21 |
| F2 | 7942 | 1713 | 220 | 1675 | 3608 | 4334 | 28 |
| F36 sample | 7942 | 1713 | 220 | 1675 | 3608 | 4334 | 28 |

F2-family exact-cell metadata audit: **23 floors / 0 mismatches**.

---

# 11. PHASE 8B HARDENING VERIFICATION

Source regression after Gate A/B/C and v1.8.2 metadata updates:

```text
26 PASS
34 PASS
34 PASS
20 PASS
---------
114 / 114 PASS
```

Required release audits:

- Room Navigation audit
- Ground Footprint audit
- Navigation Occupancy audit (25 floors / 219 workstations)
- WorkSeat audit
- Phase 6 Spatial audit
- Central audit
- F2 gameplay-metadata/reception family audit

A release is canonical only after the actual ZIP is fresh-extracted and the tests/audits pass from that fresh extraction with `release_clean=true`.

---

# 12. LEAN RELEASE POLICY

Keep canonical assets/shared blobs, registries/contracts, runtime, tests, schemas and small reports.

Do not package:

- `PREVIEW/`
- generated QA GIF/PNG bundles
- `WORLD/COMPILED_NAV/OCCUPANCY/`
- `__pycache__/`
- `.pytest_cache/`
- `*.pyc`

Per-floor navigation occupancy remains runtime-derived/cache-optional.

---

# 13. NEXT — PHASE 8C

After v1.8.2 is verified and frozen, the next implementation milestone is the real portal lifecycle:

```text
load floor
→ spawn on portal inside strip
→ fade in
→ normal movement
→ return to portal
→ cross inside → outside
→ fade/despawn
```

Do not reopen Phase 8B geometry unless a new author-approved regression requires it.
